# Roteiro de Defesa da PAP - VaiJogar

## Abertura

Bom dia/boa tarde. O meu nome e Elizandro Miguel Hossi Marques Novo e a minha PAP chama-se VaiJogar.

O VaiJogar e uma plataforma web criada para ajudar utilizadores a descobrir clubes desportivos em Portugal e a marcar treinos de forma simples. A plataforma foca-se em tres modalidades: futebol, basquetebol e voleibol.

## Problema

O problema que tentei resolver foi a dificuldade em encontrar, num unico local, informacao organizada sobre clubes, escalões, horarios, contactos e possibilidade de marcacao de treinos.

Muitas vezes essa informacao esta espalhada por redes sociais, sites diferentes ou paginas desatualizadas. O VaiJogar centraliza essa informacao e torna o processo mais direto para o utilizador.

## Objetivos

Os principais objetivos do projeto foram:

- permitir registo e login de utilizadores;
- permitir exploracao de clubes por modalidade;
- mostrar clubes num mapa interativo;
- apresentar detalhes de cada clube;
- permitir marcacao de treinos;
- gerir vagas por escalao e por sessao;
- gerar comprovativo em PDF;
- permitir ao utilizador consultar o historico;
- disponibilizar um painel de administracao;
- suportar varios idiomas.

## Tecnologias

No desenvolvimento utilizei:

- HTML, CSS e JavaScript para a interface;
- PHP para a logica do servidor;
- MySQL para a base de dados;
- XAMPP como ambiente local;
- Leaflet para os mapas;
- EmailJS para envio de emails;
- JSON para traducoes;
- MySQL Workbench para modelacao e gestao da base de dados.

## Demonstracao sugerida

1. Abrir a pagina inicial.
2. Fazer login com a conta de administrador ou com uma conta normal.
3. Mostrar a pagina de escolha de modalidade.
4. Abrir uma modalidade, por exemplo futebol.
5. Mostrar o mapa, os marcadores, a pesquisa e a lista de clubes.
6. Abrir a pagina de detalhe de um clube.
7. Mostrar escalões, horarios, contactos e planos.
8. Fazer uma marcacao de treino.
9. Abrir o historico de marcacoes.
10. Gerar o comprovativo em PDF.
11. Abrir o painel de administracao e mostrar gestao de utilizadores, clubes, horarios e marcacoes.

## Pontos tecnicos para destacar

- As palavras-passe sao guardadas com `password_hash`, nao em texto simples.
- O login verifica a palavra-passe com `password_verify`.
- Foram usados prepared statements para reduzir risco de SQL Injection.
- Existem tokens CSRF em operacoes sensiveis.
- A base de dados esta organizada por entidades relacionadas, como utilizadores, clubes, planos, escalões, horarios, marcacoes e pagamentos.
- O sistema de vagas impede que uma sessao continue disponivel depois de esgotar.
- O painel admin separa funcoes normais de funcoes administrativas.

## Dificuldades encontradas

Durante o desenvolvimento, algumas dificuldades foram:

- organizar a base de dados para suportar clubes, escalões, horarios, planos e marcacoes;
- controlar corretamente as vagas por sessao;
- integrar mapas e geolocalizacao;
- manter a interface coerente em varias paginas;
- garantir que o utilizador comum e o administrador tinham permissoes diferentes;
- preparar o suporte multilingue.

## Melhorias futuras

No futuro, o projeto poderia evoluir com:

- pagamento real integrado com uma entidade certificada;
- area propria para clubes gerirem os seus dados;
- avaliacoes reais feitas pelos utilizadores;
- notificacoes automaticas;
- pesquisa mais avancada por distancia, preco e idade;
- versao responsiva ainda mais otimizada para telemovel;
- publicacao online num servidor real.

## Fecho

Com este projeto consegui aplicar conhecimentos de programacao web, bases de dados, seguranca, APIs externas e organizacao de um sistema completo.

O VaiJogar demonstra uma solucao pratica para aproximar utilizadores e clubes desportivos, centralizando informacao e simplificando a marcacao de treinos.

