# Checklist de Demonstracao - VaiJogar

## Estado confirmado

Testes realizados em 13/06/2026:

- Apache do XAMPP ativo.
- MySQL do XAMPP ativo.
- Ligacao PHP -> MySQL confirmada.
- Base de dados `vaijogar` com 15 tabelas.
- Dados existentes:
  - 2 utilizadores;
  - 2 administradores;
  - 94 clubes;
  - 3 planos;
  - 658 escalões;
  - 1870 horarios;
  - 2 marcacoes.
- Login admin confirmado:
  - Email: `admin@vaijogar.pt`
  - Palavra-passe: `VaiJogar2026!`
- Site responde em `http://127.0.0.1/VaiJogar/`.

## Paginas testadas

Estas paginas responderam com sucesso:

- `index.php`
- `escolha.php`
- `mapa.php`
- `basket.php`
- `volei.php`
- `clube.php?id=1`
- `booking-simples.php?club_id=1`
- `marcacoes.php`
- `admin.php`

## APIs testadas

Estas chamadas responderam corretamente:

- clubes por modalidade;
- detalhe do clube FC Porto;
- planos;
- marcacoes do utilizador;
- lista de utilizadores no admin;
- lista de clubes no admin;
- lista de marcacoes no admin.

## Antes de apresentar

1. Abrir o painel do XAMPP.
2. Confirmar que Apache esta verde/ativo.
3. Confirmar que MySQL esta verde/ativo.
4. Abrir `http://127.0.0.1/VaiJogar/`.
5. Fazer login com `admin@vaijogar.pt` e `password`.
6. Abrir `escolha.php`.
7. Abrir a modalidade futebol.
8. Mostrar o mapa e a lista de clubes.
9. Abrir o FC Porto ou outro clube com dados completos.
10. Mostrar planos, escalões e horarios.
11. Mostrar o historico de marcacoes.
12. Gerar ou abrir um comprovativo PDF.
13. Abrir o painel admin.
14. Mostrar utilizadores, clubes e marcacoes.

## Plano B para a defesa

Se a internet falhar:

- explicar que mapas, rotas, logos externas e envio de email dependem de servicos online;
- mostrar as paginas locais que continuam a funcionar;
- mostrar a base de dados e o painel admin.

Se uma marcacao nova falhar durante a demonstracao:

- mostrar as marcacoes ja existentes no admin;
- mostrar o historico;
- mostrar o PDF de uma marcacao existente.

Se o login falhar:

- confirmar que o MySQL esta iniciado;
- confirmar que a base de dados `vaijogar` esta importada;
- confirmar a conta `admin@vaijogar.pt`.

