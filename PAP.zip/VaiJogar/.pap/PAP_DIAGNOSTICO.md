# Diagnostico da PAP - VaiJogar

Data: 13/06/2026

## Estado geral

O projeto e uma plataforma web em PHP/MySQL para descoberta de clubes desportivos, marcacao de treinos, gestao de utilizadores, pagamentos simulados/MB WAY, geracao de comprovativo PDF, area de perfil, painel de administracao e suporte multilingue.

## Ficheiros analisados

- Projeto PHP: `C:\xampp\htdocs\VaiJogar`
- Relatorio: `C:\Users\AEPAREDE1492\Downloads\Relatorio_PAP.docx`
- Base de dados:
  - `ESTRUTURAPAP.sql`
  - `DADOSPAP.sql`
  - `vagas_fix.sql`
- Backup indicado: `C:\xampp\htdocs\PAP_BACKUP.zip`

## Verificacoes feitas

- Os ficheiros PHP foram verificados com o PHP do XAMPP.
- Resultado: nao foram encontrados erros de sintaxe nos ficheiros `.php`.
- Os ficheiros SQL principais abrem corretamente em UTF-8.
- O relatorio foi lido a partir de uma copia temporaria, porque o ficheiro original estava aberto/bloqueado por outro processo.
- A ligacao a base de dados foi novamente testada com o XAMPP ativo e funcionou corretamente.
- O site respondeu em `http://127.0.0.1/VaiJogar/`.
- O login admin foi testado com sucesso.
- Paginas principais testadas por HTTP sem erros PHP visiveis: `escolha.php`, `mapa.php`, `basket.php`, `volei.php`, `marcacoes.php`, `admin.php`, `booking-simples.php` e `clube.php`.
- APIs principais testadas com sucesso: clubes por modalidade, detalhe de clube, planos, marcacoes do utilizador, lista de utilizadores admin, lista de clubes admin e lista de marcacoes admin.

## Pontos fortes do projeto

- Estrutura funcional completa: login, registo, recuperacao de palavra-passe, perfil, mapas, clubes, marcacoes, historico e administracao.
- Base de dados relacional bem separada em tabelas como `utilizadores`, `clubes`, `planos`, `escaloes`, `horarios`, `marcacoes`, `pagamentos`, `avaliacoes` e `favoritos`.
- Uso de `password_hash` e `password_verify` para palavras-passe.
- Uso de prepared statements em varias operacoes de base de dados.
- Protecao CSRF presente em operacoes sensiveis.
- Sistema de vagas por escalao e por sessao documentado.
- Suporte a tres idiomas atraves de ficheiros JSON.
- Relatorio bastante completo, com descricao das paginas e funcionalidades.

## Correcoes recomendadas antes da entrega

### Relatorio

- Atualizar o indice no Word para remover textos como `TOC`, `PAGEREF` e paginas erradas.
- Corrigir erros de escrita:
  - "aos meu colegas" -> "aos meus colegas"
  - "familia" -> "familia" com acento no documento final
  - "e agora.." deve ser removido ou reescrito
  - "Indice" -> "Indice" com acento no documento final
  - "Pagina" -> "Pagina" com acento no documento final
  - "registro" -> em Portugal, preferir "registo"
  - "Admininstrador" -> "Administrador"
- Rever frases repetidas na introducao, porque a ideia central aparece mais do que uma vez.
- Confirmar no relatorio se todas as funcionalidades descritas estao realmente demonstraveis no projeto.
- Na conclusao, reforcar:
  - dificuldades encontradas;
  - aprendizagens tecnicas;
  - melhorias futuras;
  - impacto do projeto.

### Base de dados

- Limpar o inicio de `vagas_fix.sql`, que contem:
  - uma atualizacao duplicada;
  - o comentario `-- ... resto do script ...`.
- Garantir que a ordem de importacao e apresentada claramente:
  1. `ESTRUTURAPAP.sql`
  2. `DADOSPAP.sql`
  3. `vagas_fix.sql`
- Confirmar que os scripts usam sempre `utf8mb4`.

### Projeto PHP

- Confirmar que Apache e MySQL continuam iniciados no painel do XAMPP antes da apresentacao.
- Confirmar que a conta de administrador funciona:
  - Email: `admin@vaijogar.pt`
  - Password documentada nos dados: `password`
- Testar o percurso principal:
  1. Login
  2. Escolha de modalidade
  3. Mapa
  4. Detalhe de clube
  5. Marcacao
  6. Historico
  7. PDF
  8. Painel admin
- Verificar se as APIs externas usadas no relatorio funcionam no computador de apresentacao.

## Riscos para a defesa

- Se a base de dados nao estiver importada corretamente ou se o MySQL estiver desligado, varias paginas podem falhar.
- Se o relatorio disser que uma funcionalidade envia email real, mas na pratica apenas gera token/link para teste, isso deve ser explicado com cuidado.
- Se a internet falhar, logos externas, mapas ou rotas podem nao carregar.
- O backup zip nao foi extraido nesta verificacao porque o acesso direto ao ficheiro foi negado pelo sistema.

## Proxima etapa sugerida

O passo seguinte deve ser uma verificacao visual em browser com o XAMPP ativo:

1. Abrir `http://localhost/VaiJogar/`
2. Entrar com a conta admin
3. Testar uma marcacao completa
4. Gerar PDF
5. Abrir o painel admin
6. Corrigir qualquer erro que apareca no fluxo real
