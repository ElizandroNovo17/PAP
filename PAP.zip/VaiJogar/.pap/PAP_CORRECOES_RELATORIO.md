# Correcoes Recomendadas no Relatorio

Este ficheiro serve como guia para rever o documento `Relatorio_PAP.docx` antes da entrega.

## Correcoes imediatas

| Onde aparece | Corrigir para |
| --- | --- |
| `aos meu colegas` | `aos meus colegas` |
| `familia` | `familia` com acento no Word |
| `e agora..` | remover ou reescrever |
| `Indice` | `Indice` com acento no Word |
| `Pagina` | `Pagina` com acento no Word |
| `registro` | `registo` |
| `Admininstrador` | `Administrador` |
| `Recuperacao da senha` | `Recuperacao da palavra-passe` |
| `á marcações` | `as marcacoes` ou `relativa as marcacoes` |

Nota: este ficheiro esta em ASCII por seguranca, mas no Word deves usar os acentos corretamente.

## Indice

O indice do documento precisa de ser atualizado no Word.

No documento aparecem campos como:

- `TOC`
- `PAGEREF`
- paginas repetidas ou erradas

No Word:

1. Clicar no indice.
2. Escolher `Atualizar Campo`.
3. Escolher `Atualizar todo o indice`.

## Introducao

A introducao esta boa, mas repete varias vezes a mesma ideia:

- centralizar informacao de clubes;
- permitir encontrar clubes;
- permitir marcar treinos;
- usar mapas interativos.

Sugestao: manter uma versao mais direta, com esta estrutura:

1. Apresentacao do aluno e do contexto da PAP.
2. Problema identificado.
3. Solucao criada.
4. Publico-alvo.
5. Tecnologias/areas trabalhadas.

## Funcionalidades a confirmar na demonstracao

Antes da entrega, confirma se consegues demonstrar:

- login;
- registo;
- recuperacao de palavra-passe;
- escolha de modalidade;
- mapa de futebol;
- mapa de basquetebol;
- mapa de voleibol;
- detalhe de clube;
- marcacao de treino;
- historico de marcacoes;
- comprovativo PDF;
- painel de administracao;
- traducao PT/EN/ES.

Se alguma funcionalidade nao estiver estavel no dia da apresentacao, explica-a como funcionalidade implementada parcialmente ou dependente de servicos externos.

## Frases melhores para usar no relatorio

### Problema

Antes:

> O projeto surgiu da necessidade de centralizar informacao sobre clubes...

Melhor:

> O projeto surgiu da dificuldade em encontrar, num unico local, informacao organizada sobre clubes desportivos, horarios, contactos, escalões e possibilidades de inscricao em treinos.

### Solucao

> Para responder a esse problema, desenvolvi o VaiJogar, uma plataforma web que permite pesquisar clubes por modalidade, consultar informacao detalhada, visualizar localizacoes num mapa interativo e realizar marcacoes de treinos.

### Aprendizagem

> Ao longo do desenvolvimento aprofundei conhecimentos em programacao web, bases de dados relacionais, autenticacao de utilizadores, integracao de APIs externas e seguranca em aplicacoes web.

### Conclusao

> Apesar das dificuldades encontradas, o projeto permitiu-me construir uma aplicacao funcional e coerente com os objetivos definidos. O VaiJogar demonstra a aplicacao pratica das competencias adquiridas ao longo do curso e pode ser evoluido futuramente com pagamentos reais, area de gestao para clubes e publicacao online.

## Cuidados na defesa

- Ter o XAMPP aberto.
- Confirmar que Apache e MySQL estao iniciados.
- Confirmar que a base de dados `vaijogar` existe.
- Ter uma conta pronta para login.
- Ter uma marcacao ja criada, caso a criacao falhe durante a apresentacao.
- Testar o PDF antes.
- Evitar depender totalmente da internet para logos, mapas ou emails.

